package com.Phyrex.demo;

import com.Phyrex.demo.BTConnectable;
import com.Phyrex.demo.BTCommunicator;
import com.Phyrex.demo.DeviceListActivity;
import com.actionbarsherlock.app.SherlockActivity;


import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;

import java.io.IOException;


public class MainActivity extends SherlockActivity implements BTConnectable{
	
	////////Inicializacion del Task
	Task task = new Task(this);
	///////////////////
	//Toast ara mensajes
	private Toast reusableToast;
	///////////////////////
	///////////////////Variables Conexi�n Bluetooth////////////////////////////////////////
	private boolean pairing;
	private static boolean btOnByUs = false;
	private BTCommunicator myBTCommunicator = null;
	private Handler btcHandler;
	private boolean connected = false;
    private static final int REQUEST_CONNECT_DEVICE = 1000;
    private static final int REQUEST_ENABLE_BT = 2000;
    private ProgressDialog connectingProgressDialog;
    private Activity thisActivity;
    private boolean btErrorPending = false;
    
    //////////////////////////////////
	
    //***********Botones y texview*************////
    TextView state;
    Button bncnt;
    Button action;
    Button action2;
    Button caminar;
    ///////////////////////
    
    /////*********Valores de motores*********//////
    private int motorAction;
    private int directionAction;
  
    ///////////////////////////////////
    
    /////Detecta si el Bluetooth esta activado////////////
    public static boolean isBtOnByUs() {
        return btOnByUs;
    }
	
    ///detecta si se activo el bluetooth////////
    public static void setBtOnByUs(boolean btOnByUs) {
        MainActivity.btOnByUs = btOnByUs;
    }
    
    ///Crea un nuevo objeto para realizar la conexion///////////
    private void createBTCommunicator() {
        // interestingly BT adapter needs to be obtained by the UI thread - so we pass it in in the constructor
        myBTCommunicator = new BTCommunicator(this, myHandler, BluetoothAdapter.getDefaultAdapter(), getResources());
        btcHandler = myBTCommunicator.getHandler();
    }
    //crea y arranca un thread para la conexion bluetooth/////////////77
    //recibe la mac del robot/////////////
    private void startBTCommunicator(String mac_address) {
        connected = false;        
        connectingProgressDialog = ProgressDialog.show(this, "", getResources().getString(R.string.connecting_please_wait), true);

        if (myBTCommunicator != null) {
            try {
                myBTCommunicator.destroyNXTconnection();
            }
            catch (IOException e) { }
        }
        createBTCommunicator();
        myBTCommunicator.setMACAddress(mac_address);
        myBTCommunicator.start();
    }
    
    ////Termina la conexion bluetooth (destruye el thread)//////////
    public void destroyBTCommunicator() {

        if (myBTCommunicator != null) {
            sendBTCmessage(BTCommunicator.NO_DELAY, BTCommunicator.DISCONNECT, 0, 0);
            myBTCommunicator = null;
        }

        connected = false;
        //updateButtonsAndMenu();
    }

   ///muestra el Toast///
    ////recive el mensaje y la duracion del Toast///////////
    private void showToast(String textToShow, int length) {
        reusableToast.setText(textToShow);
        reusableToast.setDuration(length);
        reusableToast.show();
    }

    ///muestra el Toast///
    ////recive el mensaje  (int - ID) y la duracion del Toast///////////
    private void showToast(int resID, int length) {
        reusableToast.setText(resID);
        reusableToast.setDuration(length);
        reusableToast.show();
    }
    
    @Override
    protected void onStart() {
        super.onStart();
    }
    
    @Override
    public void onResume() {
        super.onResume();
    }
    ///Creacion de la actividad, inicializacion de botoes y texto.
    /// ejecucon del task
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		thisActivity = this;
		setContentView(R.layout.activity_main);
	    
		state = (TextView)findViewById(R.id.state);
		action = (Button)findViewById(R.id.action);
		action2 = (Button)findViewById(R.id.action2);
		caminar = (Button)findViewById(R.id.caminar);
		bncnt = (Button)findViewById(R.id.bncnt);
		bncnt.setOnClickListener(listener);
		action.setOnClickListener(listener);
		action2.setOnClickListener(listener);
		caminar.setOnClickListener(listener);
		state.setText("Desconectado");
		state.setTextColor(Color.parseColor("#FF0000"));
		reusableToast = Toast.makeText(this, "", Toast.LENGTH_SHORT);
		task.execute();

	}
	/////listener  para los botones////////////
	OnClickListener listener = new OnClickListener(){
		  @Override
		  public void onClick(View v) {
			  switch(v.getId()){
				case R.id.bncnt:
					
					//si no esta conectado verifica presencia de bluetooth 
					if(connected==false){
						if (BluetoothAdapter.getDefaultAdapter()==null) {
					            showToast(R.string.bt_initialization_failure, Toast.LENGTH_LONG);
					            destroyBTCommunicator();
					            finish();
					            return;
					        }            
							//si existe blublu y no esta activado lo activa
					        if (!BluetoothAdapter.getDefaultAdapter().isEnabled()) {
					            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
					            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
					        } else {//si esta activado busca dispositivos para conectarse
					           selectNXT();
					        }
					        
					}else if(connected==true){
						//si esta conectado desconecta
						destroyBTCommunicator();
					}
				        
				break;
				case R.id.action://ejecuta accion 1
					showToast(R.string.action_1, Toast.LENGTH_SHORT);
					boton1();
				break;
				case R.id.action2://ejecuta accion 2
					showToast(R.string.action_2, Toast.LENGTH_SHORT);
					boton2();    
				break;
				case R.id.caminar://ejecutar 
					showToast(R.string.caminar, Toast.LENGTH_SHORT);
					caminar();    
				break;
			  }
		  }
	};
	
	@Override
    protected void onDestroy() {
        super.onDestroy();
        destroyBTCommunicator();
        if (btOnByUs){
            showToast(R.string.bt_off_message, Toast.LENGTH_SHORT);
            BluetoothAdapter.getDefaultAdapter().disable();
        }
            task.cancel(true);
    }

    @Override
    public void onPause() {
        destroyBTCommunicator();
        super.onStop();
    }

    @Override
    public void onSaveInstanceState(Bundle icicle) {
        super.onSaveInstanceState(icicle);
    }
	 
    ///envia al bthandler los mensajes via blublu   (enteros)
    void sendBTCmessage(int delay, int message, int value1, int value2) {
        Bundle myBundle = new Bundle();
        myBundle.putInt("message", message);
        myBundle.putInt("value1", value1);
        myBundle.putInt("value2", value2);
        Message myMessage = myHandler.obtainMessage();
        myMessage.setData(myBundle);

        if (delay == 0)
            btcHandler.sendMessage(myMessage);

        else
            btcHandler.sendMessageDelayed(myMessage, delay);
    }

  ///envia al bthandler los mensajes via blublu   (string)  
    void sendBTCmessage(int delay, int message, String name) {
        Bundle myBundle = new Bundle();
        myBundle.putInt("message", message);
        myBundle.putString("name", name);
        Message myMessage = myHandler.obtainMessage();
        myMessage.setData(myBundle);

        if (delay == 0)
            btcHandler.sendMessage(myMessage);
        else
            btcHandler.sendMessageDelayed(myMessage, delay);
    }
    //llama a la actividad que  busca dispositivos
    void selectNXT() {
        Intent serverIntent = new Intent(this, DeviceListActivity.class);
        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
    }
    
    //ejecuta la accion del boton 1, toca mozart y mueve el motor A
    private void boton1() {
    		motorAction = BTCommunicator.MOTOR_A;
    		directionAction = 1;
            // Wolfgang Amadeus Mozart 
            // "Zauberfloete - Der Vogelfaenger bin ich ja"
            sendBTCmessage(BTCommunicator.NO_DELAY, 
                BTCommunicator.DO_BEEP, 392, 100);
            sendBTCmessage(200, BTCommunicator.DO_BEEP, 440, 100);
            sendBTCmessage(400, BTCommunicator.DO_BEEP, 494, 100);
            sendBTCmessage(600, BTCommunicator.DO_BEEP, 523, 100);
            sendBTCmessage(800, BTCommunicator.DO_BEEP, 587, 300);
            sendBTCmessage(1200, BTCommunicator.DO_BEEP, 523, 300);
            sendBTCmessage(1600, BTCommunicator.DO_BEEP, 494, 300);
            
            int direction =  1;                
		    sendBTCmessage(BTCommunicator.NO_DELAY, motorAction, 
		        75*direction*directionAction, 0);
		    sendBTCmessage(500, motorAction, 
		        -75*direction*directionAction, 0);
		    sendBTCmessage(1000, motorAction, 0, 0);


    }       
    
    //ejecuta la accion del boton 1, toca musica y mueve el motor A
    private void boton2() {
		motorAction = BTCommunicator.MOTOR_A;
		directionAction = 1;
        // G-F-E-D-C
        sendBTCmessage(BTCommunicator.NO_DELAY, 
            BTCommunicator.DO_BEEP, 392, 100);
        sendBTCmessage(200, BTCommunicator.DO_BEEP, 349, 100);
        sendBTCmessage(400, BTCommunicator.DO_BEEP, 330, 100);
        sendBTCmessage(600, BTCommunicator.DO_BEEP, 294, 100);
        sendBTCmessage(800, BTCommunicator.DO_BEEP, 262, 300);

        int direction =  -1;                
        sendBTCmessage(BTCommunicator.NO_DELAY, motorAction, 
            75*direction*directionAction, 0);
        sendBTCmessage(500, motorAction, 
            -75*direction*directionAction, 0);
        sendBTCmessage(1000, motorAction, 0, 0);

    }
	
    ///ejecuta funciones para caminar
    private void caminar() {
		motorAction = BTCommunicator.MOTOR_B;
		directionAction = 1;

	    int direction =  1;                
	    sendBTCmessage(BTCommunicator.NO_DELAY, motorAction, 75*direction*directionAction, 0);
	    sendBTCmessage(1000, motorAction, 0, 0);
	    motorAction = BTCommunicator.MOTOR_C;
		directionAction = 1;
		sendBTCmessage(BTCommunicator.NO_DELAY, motorAction, 75*direction*directionAction, 0);
		sendBTCmessage(1000, motorAction, 0, 0);

}
    
    private int byteToInt(byte byteValue) {
        int intValue = (byteValue & (byte) 0x7f);

        if ((byteValue & (byte) 0x80) != 0)
            intValue |= 0x80;

        return intValue;
    }
    
    //retorna si esta pareado 
    @Override
    public boolean isPairing() {
        return pairing;
    }
    
    //recibe datos de dispositivo e inicia la conexion
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE:

                
                if (resultCode == Activity.RESULT_OK) {
                    String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
                    pairing = data.getExtras().getBoolean(DeviceListActivity.PAIRING);
                    startBTCommunicator(address);
                    
                }
                
                break;
                
            case REQUEST_ENABLE_BT:

                // When the request to enable Bluetooth returns
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        btOnByUs = true;
                        selectNXT();
                        break;
                    case Activity.RESULT_CANCELED:
                        showToast(R.string.bt_needs_to_be_enabled, Toast.LENGTH_SHORT);
                        finish();
                        break;
                    default:
                        showToast(R.string.problem_at_connecting, Toast.LENGTH_SHORT);
                        finish();
                        break;
                }
                
                break;
             
        }
    }
    
    
    //administra los errores que pueden suceder antes y durante la conexion.
    final Handler myHandler = new Handler() {
        @Override
        public void handleMessage(Message myMessage) {
            switch (myMessage.getData().getInt("message")) {
                case BTCommunicator.DISPLAY_TOAST:
                    showToast(myMessage.getData().getString("toastText"), Toast.LENGTH_SHORT);
                    break;
                case BTCommunicator.STATE_CONNECTED:
                    connected = true;
                    connectingProgressDialog.dismiss();
                    sendBTCmessage(BTCommunicator.NO_DELAY, BTCommunicator.GET_FIRMWARE_VERSION, 0, 0);
                    break;
                    
                case BTCommunicator.MOTOR_STATE:

                    if (myBTCommunicator != null) {
                        byte[] motorMessage = myBTCommunicator.getReturnMessage();
                        int position = byteToInt(motorMessage[21]) + (byteToInt(motorMessage[22]) << 8) + (byteToInt(motorMessage[23]) << 16)
                                       + (byteToInt(motorMessage[24]) << 24);
                        showToast(getResources().getString(R.string.current_position) + position, Toast.LENGTH_SHORT);
                    }

                    break;

                case BTCommunicator.STATE_CONNECTERROR_PAIRING:
                    connectingProgressDialog.dismiss();
                    destroyBTCommunicator();
                    break;

                case BTCommunicator.STATE_CONNECTERROR:
                    connectingProgressDialog.dismiss();
                case BTCommunicator.STATE_RECEIVEERROR:
                case BTCommunicator.STATE_SENDERROR:

                    destroyBTCommunicator();
                    if (btErrorPending == false) {
                        btErrorPending = true;
                        // inform the user of the error with an AlertDialog
                        AlertDialog.Builder builder = new AlertDialog.Builder(thisActivity);
                        builder.setTitle(getResources().getString(R.string.bt_error_dialog_title))
                        .setMessage(getResources().getString(R.string.bt_error_dialog_message)).setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                btErrorPending = false;
                                dialog.cancel();
                                //agregar re conexion
                                selectNXT();
                            }
                        });
                        builder.create().show();
                    }

                    break;

                	case BTCommunicator.FIRMWARE_VERSION:

                    if (myBTCommunicator != null) {
                        byte[] firmwareMessage = myBTCommunicator.getReturnMessage();
                        // check if we know the firmware
                        for (int pos=0; pos<4; pos++) {
                            if (firmwareMessage[pos + 3] != LCPMessage.FIRMWARE_VERSION_LEJOSMINDDROID[pos]) {
                                break;
                            }
                        }
                    }

                    break;
                
             
            }
        }
    };
    
    //task para realizar tareas paralelas
    private class Task extends AsyncTask<Void, Integer, Void>{
		
    	

		public Task(MainActivity mainActivity) {
			// TODO Auto-generated constructor stub
		}

		@Override
	    protected void onPreExecute() {
	    	super.onPreExecute();
	    }
	      
	    @Override
	    protected Void doInBackground(Void... params) {
	    	//ejecuta tarea cada 30ms
	    	int tiempo = 30;
	    	boolean flag= true;	
	    	while(flag){
	    		publishProgress(); 
	    		SystemClock.sleep(tiempo);
	    	}
	    	return null;
	    }
	  
	    @Override
	    protected void onProgressUpdate(Integer... values) {
	    	super.onProgressUpdate(values);
	    	//si no esta conectado desactiva botones de accion y setea textos de botones y texview
	    	if(connected==false){
				state.setText(R.string.Desconectado);
				state.setTextColor(Color.parseColor("#FF0000"));
				action.setClickable(false);
				action2.setClickable(false);
				caminar.setClickable(false);
				bncnt.setText(R.string.Conectar);
			}else if(connected==true){//si esta conectado activa botones y setea texto.
				state.setText(R.string.Conectado);
				state.setTextColor(Color.parseColor("#00FF00"));
				action.setClickable(true);
				action2.setClickable(true);
				caminar.setClickable(true);
				bncnt.setText(R.string.Desconectar);
			}
		}	   
	}

    
}
