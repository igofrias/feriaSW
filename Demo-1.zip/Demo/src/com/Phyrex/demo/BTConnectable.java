/**
 *   (Changes from original are) Copyright 2010 Guenther Hoelzl, Shawn Brown
 * 
 * (original work is) Copyright (C) 2009 The Android Open Source Project
**/

package com.Phyrex.demo;

public interface BTConnectable {

    /**
     * @return true, when currently pairing 
     */
    public boolean isPairing();

}
